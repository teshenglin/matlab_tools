function out = dfsroot() 
% Which directory am I in? 

out = fileparts(which('dfsroot'));

end
