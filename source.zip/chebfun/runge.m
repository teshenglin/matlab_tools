function runge
% Select interpolation points by right clicking.
% When you get bored, left or double click to finish.

F = @(x) 1./(1+25*x.^2);

% initialise
x = [];
t = linspace(-1, 1, 1000);
LW = 'LineWidth'; MS = 'MarkerSize';
fv = F(t);
afv = max(fv)+1;
ifv = min(fv)-1;

% loop
figure
plot(t,fv,'-k',LW,2);
axis([-1 1 ifv afv])
hold on
h1 = plot(t, fv, '-b', LW, 2);
h2 = plot(t, F(t)*0, '-r', LW, 2);
shg

legend('original function', 'interpolant', 'difference')

while 1                          % keep clicking!
    if ( ~isempty(x) )
        plot(x,F(x),'.b',MS,20,'HandleVisibility','off')      % plot interpolation points
        plot(x,0,'*k',MS,6,'HandleVisibility','off')   % plot x values alone
        p = polyfit(x, F(x), length(x)-1);
        f = polyval(p, t);
        h1.YData = f;
        h2.YData = f-fv;
        axis([-1 1 ifv afv])
        drawnow
        shg
    end
    [gx, ~, button] = ginput(1);    % input new interpolation point
    if ( button == 3 ) break, end  % if right button, stop
    x = unique([x; gx]);           % #ok<AGROW>
end
end